# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all, collect_submodules

datas = [('icon.ico', '.')]
binaries = []
hiddenimports = []

# Collect CustomTkinter assets
tmp_ret = collect_all('customtkinter')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]

# Collect WinOCR & WinRT modules
hiddenimports += collect_submodules('winocr')
for winrt_mod in [
    'winrt.windows.foundation',
    'winrt.windows.foundation.collections',
    'winrt.windows.globalization',
    'winrt.windows.graphics.imaging',
    'winrt.windows.media.ocr',
    'winrt.windows.storage.streams',
]:
    try:
        tmp_ret = collect_all(winrt_mod)
        datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]
    except Exception:
        hiddenimports.append(winrt_mod)

a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'torch', 'torchvision', 'torchaudio',
        'onnxruntime', 'rapidocr_onnxruntime', 'cv2',
        'scipy', 'matplotlib', 'pandas', 'numpy',
        'IPython', 'notebook', 'pytest',
        'sympy', 'sklearn', 'jupyter',
        'pyautogui', 'pyscreeze', 'mouseinfo', 'pymsgbox',
        'pytweening', 'pygetwindow', 'pyrect', 'pyperclip',
        'winsdk', 'manga_ocr', 'google', 'googleapiclient',
        'grpc', 'transformers', 'tokenizers', 'safetensors',
        'huggingface_hub', 'openai', 'pydantic', 'pydantic_core',
        'watchfiles', 'websockets', 'uvicorn', 'anyio',
        'httptools', 'h11', 'httpcore', 'httpcore2', 'httpx', 'httpx2',
        'PIL._webp', 'PIL._avif', 'PIL._imagingcms', 'PIL._imagingmath',
        'tkinter.test', 'unittest', 'test'
    ],
    noarchive=False,
    optimize=2,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='Antigravity_Auto_Clicker',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['icon.ico'],
)
