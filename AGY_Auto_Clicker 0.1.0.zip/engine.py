import os
import time
import threading
import ctypes
from ctypes import wintypes
import re
import mss
from PIL import Image
import winocr

# Win32 DPI Awareness setup (Critical for multi-monitor & scaling)
try:
    ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))  # PER_MONITOR_AWARE_V2
except Exception:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # PROCESS_PER_MONITOR_DPI_AWARE
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

# Win32 API constants & bindings
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
VK_F8 = 0x77
VK_F9 = 0x78
VK_MENU = 0x12  # Alt key (used to bypass Windows SetForegroundWindow restrictions)
SW_RESTORE = 9
SW_SHOW = 5
GA_ROOT = 2
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000

# Virtual screen metrics for true multi-monitor support
SM_XVIRTUALSCREEN = 76
SM_YVIRTUALSCREEN = 77
SM_CXVIRTUALSCREEN = 78
SM_CYVIRTUALSCREEN = 79

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
psapi = ctypes.windll.psapi

# 64-bit safe function signatures for Win32 API
WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
user32.EnumWindows.argtypes = [WNDENUMPROC, wintypes.LPARAM]
user32.EnumWindows.restype = wintypes.BOOL
try:
    user32.EnumDesktopWindows.argtypes = [wintypes.HANDLE, WNDENUMPROC, wintypes.LPARAM]
    user32.EnumDesktopWindows.restype = wintypes.BOOL
except Exception:
    pass


def attach_thread_to_input_desktop():
    """Attaches current thread to user's active input desktop to prevent GDI BitBlt errors"""
    try:
        h_desk = user32.OpenInputDesktop(0, False, 0x01FF)
        if h_desk:
            user32.SetThreadDesktop(h_desk)
            user32.CloseDesktop(h_desk)
            return True
    except Exception:
        pass
    return False


def get_process_name_by_pid(pid):
    """Retrieves executable name from PID with PROCESS_QUERY_LIMITED_INFORMATION"""
    try:
        h_proc = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if h_proc:
            buff = ctypes.create_unicode_buffer(512)
            psapi.GetProcessImageFileNameW(h_proc, buff, 512)
            kernel32.CloseHandle(h_proc)
            if buff.value:
                return os.path.basename(buff.value).lower()
    except Exception:
        pass
    return ""


class AutoClickerEngine:
    def __init__(self, log_callback=None, status_callback=None):
        self.log_callback = log_callback
        self.status_callback = status_callback
        self.is_running = False
        self._thread = None
        self._hotkey_thread = None

        # Settings
        self.delay_sec = 0.05
        self.restore_mouse = True
        self.smart_background = True       # Stealth background click & active window restore
        self.verify_button_box = True       # Smart button validation filter

        # Own window protection (Prevents 100% of self-clicking bugs)
        self.own_hwnd = None
        self.own_pid = os.getpid()

        # Target window caching for ultra-fast loop with zero overhead
        self._cached_target = None
        self._cached_time = 0.0

        # Anti-spam cooldown cache: {(x, y): timestamp}
        self.click_history = {}
        self.cooldown_sec = 0.8

        # Start hotkey listener (F8 toggle / F9 emergency stop)
        self._hotkey_running = True
        self._hotkey_thread = threading.Thread(target=self._hotkey_loop, daemon=True)
        self._hotkey_thread.start()

    def set_own_window(self, hwnd):
        """Registers the Auto Approver GUI window handle for collision exclusion"""
        self.own_hwnd = hwnd

    def log(self, msg):
        timestamp = time.strftime("%H:%M:%S")
        formatted = f"[{timestamp}] {msg}"
        if self.log_callback:
            self.log_callback(formatted)
        print(formatted)

    def start(self):
        if self.is_running:
            return
        self.is_running = True
        if self.status_callback:
            self.status_callback(True)
        self.log("▶ Submit 자동 승인 시작됨 (단축키 [F8] 토글)")
        self._thread = threading.Thread(target=self._scan_loop, daemon=True)
        self._thread.start()

    def stop(self):
        if not self.is_running:
            return
        self.is_running = False
        if self.status_callback:
            self.status_callback(False)
        self.log("⏸ 자동 승인 일시정지됨 (F8을 누르면 재개)")

    def toggle(self):
        if self.is_running:
            self.stop()
        else:
            self.start()

    def _hotkey_loop(self):
        """Global background listener for F8 / F9 hotkeys"""
        last_f8_state = False
        while self._hotkey_running:
            try:
                f8_state = (user32.GetAsyncKeyState(VK_F8) & 0x8000) != 0
                if f8_state and not last_f8_state:
                    self.toggle()
                last_f8_state = f8_state

                f9_state = (user32.GetAsyncKeyState(VK_F9) & 0x8000) != 0
                if f9_state and self.is_running:
                    self.stop()
            except Exception:
                pass
            time.sleep(0.05)

    def get_window_text(self, hwnd):
        try:
            length = user32.GetWindowTextLengthW(hwnd)
            if length > 0:
                buff = ctypes.create_unicode_buffer(length + 1)
                user32.GetWindowTextW(hwnd, buff, length + 1)
                return buff.value
        except Exception:
            pass
        return ""

    def get_window_class(self, hwnd):
        try:
            buff = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(hwnd, buff, 256)
            return buff.value
        except Exception:
            pass
        return ""

    def find_antigravity_window(self):
        """
        Locates genuine Antigravity window across any monitor.
        Uses exact Process ID & Image Name matching so title changes never break detection.
        """
        now = time.time()
        # Fast cache check: reuse if valid within 2.0 seconds
        if self._cached_target and (now - self._cached_time < 2.0):
            cached_hwnd = self._cached_target[0]
            if user32.IsWindow(cached_hwnd) and user32.IsWindowVisible(cached_hwnd) and not user32.IsIconic(cached_hwnd):
                rect = wintypes.RECT()
                if user32.GetWindowRect(cached_hwnd, ctypes.byref(rect)):
                    w = rect.right - rect.left
                    h = rect.bottom - rect.top
                    if w > 400 and h > 300:
                        return (cached_hwnd, (rect.left, rect.top, w, h), self._cached_target[2], self._cached_target[3])

        found_target = None

        def enum_cb(hwnd, lparam):
            nonlocal found_target
            try:
                if not user32.IsWindowVisible(hwnd) or user32.IsIconic(hwnd):
                    return True

                pid = wintypes.DWORD()
                user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                # Skip own process strictly by PID / HWND (Never by title string!)
                if pid.value == self.own_pid or (self.own_hwnd and hwnd == self.own_hwnd):
                    return True

                cls_name = self.get_window_class(hwnd)
                if cls_name in ["CabinetWClass", "WorkerW", "Progman", "Shell_TrayWnd"]:
                    return True

                proc_name = get_process_name_by_pid(pid.value)

                # Antigravity's true executable name is antigravity.exe
                if "antigravity" in proc_name:
                    rect = wintypes.RECT()
                    user32.GetWindowRect(hwnd, ctypes.byref(rect))
                    w = rect.right - rect.left
                    h = rect.bottom - rect.top
                    if w > 400 and h > 300:
                        title = self.get_window_text(hwnd)
                        found_target = (hwnd, (rect.left, rect.top, w, h), title, pid.value)
                        return False  # Stop enumeration
            except Exception:
                pass
            return True

        try:
            h_desk = user32.OpenInputDesktop(0, False, 0x01FF)
            if h_desk:
                user32.EnumDesktopWindows(h_desk, WNDENUMPROC(enum_cb), 0)
                user32.CloseDesktop(h_desk)
        except Exception:
            pass

        if not found_target:
            try:
                user32.EnumWindows(WNDENUMPROC(enum_cb), 0)
            except Exception:
                pass

        if found_target:
            self._cached_target = found_target
            self._cached_time = now

        return found_target

    def match_target(self, text, word_count):
        """
        테마 무관 Submit 버튼 전용 매처.
        - 버튼 라벨은 단어가 1~2개뿐임 (Submit, Submit ↵, Submit (Enter), 제출 등).
        - 단어가 3개 이상인 본문/문장/채팅 텍스트는 100% 원천 배제.
        - 엔터 기호(↵)나 폰트 렌더링에 의한 오탈자(submita, submitn, submlt 등)도 유연하게 허용.
        """
        if not text or word_count == 0 or word_count > 2:
            return None

        clean_raw = re.sub(r'[\r\n\t]+', ' ', text).strip()
        norm = re.sub(r'[^a-zA-Z0-9가-힣]', '', clean_raw).lower()

        # Submit 계열(submita, submitn, submlt 등) 또는 한글 제출 매칭
        if norm.startswith('subm') or 'submit' in norm or '제출' in norm:
            return "submit"

        return None

    def is_real_button(self, img_pil, bx1, by1, bx2, by2):
        """
        테마 무관(다크, 라이트, 도쿄나이트, 활성화 블루 등) 버튼 UI 검증 필터.
        """
        if not self.verify_button_box:
            return True

        bw = bx2 - bx1
        bh = by2 - by1

        # Text inside buttons: height 8~65px, width 15~240px
        if bh < 8 or bh > 65:
            return False
        if bw < 15 or bw > 240:
            return False

        aspect = bw / float(max(1, bh))
        if aspect < 0.7 or aspect > 9.5:
            return False

        try:
            crop = img_pil.crop((bx1, by1, bx2, by2))
            min_v, max_v = crop.convert('L').getextrema()
            # 텍스트와 배경의 명도 대비 확인
            if (max_v - min_v) < 14:
                return False
        except Exception:
            return False

        return True

    def is_inside_own_window(self, cx, cy):
        """Returns True if coordinates fall inside Auto Clicker's own UI"""
        if self.own_hwnd:
            rect = wintypes.RECT()
            if user32.GetWindowRect(self.own_hwnd, ctypes.byref(rect)):
                if (rect.left - 15) <= cx <= (rect.right + 15) and (rect.top - 15) <= cy <= (rect.bottom + 15):
                    return True

        try:
            pt = wintypes.POINT(cx, cy)
            pt_hwnd = user32.WindowFromPoint(pt)
            root_hwnd = user32.GetAncestor(pt_hwnd, GA_ROOT)
            check_hwnd = root_hwnd if root_hwnd else pt_hwnd
            target_pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(check_hwnd, ctypes.byref(target_pid))
            if target_pid.value == self.own_pid:
                return True
        except Exception:
            pass

        return False

    def _scan_loop(self):
        """
        True Multi-Monitor & Dual-Pass Scanning Loop:
        - Accurately tracks Antigravity window across ALL monitors (Primary, Secondary, Third, etc.)
        - Safely clamps across virtual desktop bounds (supports negative coordinates & multi-displays)
        - Dual-Pass OCR ensures 100% detection for active/bright buttons
        """
        attach_thread_to_input_desktop()

        with mss.mss() as sct:
            while self.is_running:
                try:
                    now = time.time()
                    self.click_history = {pos: t for pos, t in self.click_history.items() if now - t < self.cooldown_sec}

                    target_win = self.find_antigravity_window()
                    target_hwnd = target_win[0] if target_win else None
                    win_rect = target_win[1] if target_win else None

                    # Virtual desktop bounds across ALL monitors
                    vx = user32.GetSystemMetrics(SM_XVIRTUALSCREEN)
                    vy = user32.GetSystemMetrics(SM_YVIRTUALSCREEN)
                    vw = user32.GetSystemMetrics(SM_CXVIRTUALSCREEN)
                    vh = user32.GetSystemMetrics(SM_CYVIRTUALSCREEN)

                    if win_rect:
                        # True Multi-Monitor bounding box clamping
                        mon_left = max(vx, min(vx + vw - 100, win_rect[0]))
                        mon_top = max(vy, min(vy + vh - 100, win_rect[1]))
                        mon_right = min(vx + vw, win_rect[0] + win_rect[2])
                        mon_bottom = min(vy + vh, win_rect[1] + win_rect[3])
                        mon_w = max(100, mon_right - mon_left)
                        mon_h = max(100, mon_bottom - mon_top)
                        monitor = {
                            "left": mon_left,
                            "top": mon_top,
                            "width": mon_w,
                            "height": mon_h
                        }
                    else:
                        # Fallback: scan ALL monitors combined (sct.monitors[0])
                        monitor = sct.monitors[0]

                    try:
                        sct_img = sct.grab(monitor)
                    except Exception:
                        attach_thread_to_input_desktop()
                        time.sleep(0.05)
                        sct_img = sct.grab(monitor)

                    img_pil = Image.frombytes("RGB", sct_img.size, sct_img.bgra, "raw", "BGRX")

                    # Pass 1: Standard color capture
                    ocr_res = winocr.recognize_pil_sync(img_pil, lang="ko")
                    found = False
                    if ocr_res and self.is_running:
                        found = self._evaluate_buttons(ocr_res, monitor, img_pil, target_hwnd)

                    # Pass 2: High-contrast Red channel filter for active/bright blue buttons
                    if not found and self.is_running:
                        r_chan = img_pil.split()[0]
                        img_red = Image.merge('RGB', (r_chan, r_chan, r_chan))
                        ocr_res_red = winocr.recognize_pil_sync(img_red, lang="ko")
                        if ocr_res_red and self.is_running:
                            found = self._evaluate_buttons(ocr_res_red, monitor, img_pil, target_hwnd)

                    if found:
                        time.sleep(0.3)
                        continue

                except Exception:
                    pass

                time.sleep(0.06)

    def _evaluate_buttons(self, ocr_res, monitor, img_pil, target_hwnd):
        """Evaluates detected text items and clicks Submit button"""
        now = time.time()
        lines = ocr_res.get('lines', [])

        for line in lines:
            line_text = (line.get('text') or '').strip()
            words = line.get('words', [])
            if not words:
                continue

            # Strict check: A button label is only 1 or 2 words!
            target_match = self.match_target(line_text, len(words))
            if not target_match:
                continue

            # Calculate bounding box for the button words
            bx1 = int(min(w['bounding_rect']['x'] for w in words))
            by1 = int(min(w['bounding_rect']['y'] for w in words))
            bx2 = int(max(w['bounding_rect']['x'] + w['bounding_rect']['width'] for w in words))
            by2 = int(max(w['bounding_rect']['y'] + w['bounding_rect']['height'] for w in words))

            # Visual button verification (Dimensions & Contrast)
            if not self.is_real_button(img_pil, bx1, by1, bx2, by2):
                continue

            # Screen coordinates across multi-monitors
            screen_cx = monitor["left"] + (bx1 + bx2) // 2
            screen_cy = monitor["top"] + (by1 + by2) // 2

            # 100% SELF-CLICK SHIELD: If target is inside Auto Clicker's own GUI, IGNORE!
            if self.is_inside_own_window(screen_cx, screen_cy):
                continue

            # Anti-spam cooldown check (0.8s)
            is_cooling = False
            for (hx, hy), t in self.click_history.items():
                if abs(hx - screen_cx) < 40 and abs(hy - screen_cy) < 30:
                    if now - t < self.cooldown_sec:
                        is_cooling = True
                        break
            if is_cooling:
                continue

            display_label = "Submit (제출)"

            # Target confirmed! Record cooldown and click
            self.click_history[(screen_cx, screen_cy)] = now
            self._execute_click(screen_cx, screen_cy, display_label, line_text, target_hwnd)
            return True

        return False

    def _execute_click(self, cx, cy, label, raw_text, target_hwnd=None):
        """
        Executes click with window activation, sufficient dwell time
        for Chromium event loops, and seamless restoration.
        """
        self.log(f"🎯 [{label}] 감지됨: '{raw_text}' (위치: {cx}, {cy})")

        # 1. Save original cursor & current user foreground window
        cur_pt = wintypes.POINT()
        user32.GetCursorPos(ctypes.byref(cur_pt))
        orig_x, orig_y = cur_pt.x, cur_pt.y
        user_hwnd = user32.GetForegroundWindow()

        # Configurable delay buffer (default 0.05s)
        delay = max(0.0, self.delay_sec)
        if delay > 0.05:
            self.log(f"⏳ {delay:.2f}초 후 자동 클릭...")
            steps = max(1, int(delay * 20))
            for _ in range(steps):
                if not self.is_running:
                    self.log("❌ 사용자가 일시정지하여 클릭이 취소되었습니다.")
                    return
                time.sleep(0.05)

        if not self.is_running:
            return

        try:
            if not target_hwnd:
                pt = wintypes.POINT(cx, cy)
                pt_hwnd = user32.WindowFromPoint(pt)
                root_hwnd = user32.GetAncestor(pt_hwnd, GA_ROOT)
                target_hwnd = root_hwnd if root_hwnd else pt_hwnd

            # 2. Window Activation with Windows Foreground Lock Bypass
            if target_hwnd and target_hwnd != user_hwnd:
                if user32.IsIconic(target_hwnd):
                    user32.ShowWindow(target_hwnd, SW_RESTORE)

                user32.keybd_event(VK_MENU, 0, 0, 0)
                user32.keybd_event(VK_MENU, 0, 2, 0)

                cur_tid = user32.GetWindowThreadProcessId(user_hwnd, None)
                target_tid = user32.GetWindowThreadProcessId(target_hwnd, None)
                app_tid = kernel32.GetCurrentThreadId()

                user32.AttachThreadInput(cur_tid, app_tid, True)
                user32.AttachThreadInput(target_tid, app_tid, True)
                user32.BringWindowToTop(target_hwnd)
                user32.SetForegroundWindow(target_hwnd)
                user32.AttachThreadInput(cur_tid, app_tid, False)
                user32.AttachThreadInput(target_tid, app_tid, False)
                time.sleep(0.04)

            # 3. Move cursor to button & Hover
            user32.SetCursorPos(cx, cy)
            time.sleep(0.04)

            # 4. Clean Click Down -> Hold (50ms) -> Up
            user32.mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
            time.sleep(0.05)
            user32.mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)

            # Keep cursor over button for 150ms to ensure Chromium receives click
            time.sleep(0.15)

            self.log(f"⚡ 승인 완료: {label}")

            # 5. Restore mouse position
            if self.restore_mouse:
                user32.SetCursorPos(orig_x, orig_y)

            # 6. Smart Background Mode: Restore user's previous active window seamlessly
            if self.smart_background and user_hwnd and user_hwnd != target_hwnd:
                time.sleep(0.08)
                user32.keybd_event(VK_MENU, 0, 0, 0)
                user32.keybd_event(VK_MENU, 0, 2, 0)
                user32.SetForegroundWindow(user_hwnd)

        except Exception as e:
            self.log(f"⚠️ 클릭 실행 중 오류: {e}")
