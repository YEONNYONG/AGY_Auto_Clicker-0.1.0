import os
import sys
import time
import ctypes
from ctypes import wintypes
import customtkinter as ctk
from engine import AutoClickerEngine

# Enable Per-Monitor DPI Awareness v2 before any GUI elements initialize
try:
    ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))  # PER_MONITOR_AWARE_V2
except Exception:
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)  # PROCESS_PER_MONITOR_DPI_AWARE
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass

user32 = ctypes.windll.user32

# Configure CustomTkinter Appearance
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class ModernAutoClickerApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Antigravity Auto Clicker")
        self.geometry("460x540")
        self.minsize(420, 480)
        self.configure(fg_color="#080c14")

        # Set Window Icon
        icon_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon.ico")
        if os.path.exists(icon_path):
            try:
                self.iconbitmap(icon_path)
            except Exception:
                pass

        self.click_count = 0

        # Initialize AutoClicker Engine
        self.engine = AutoClickerEngine(
            log_callback=self.on_log,
            status_callback=self.on_status_change
        )

        self.setup_ui()

        # Register own window HWND to avoid self-clicking bugs
        self.update_idletasks()
        try:
            hwnd = user32.GetParent(self.winfo_id())
            if not hwnd:
                hwnd = self.winfo_id()
            self.engine.set_own_window(hwnd)
        except Exception:
            pass

        # Handle window close
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        # Welcome message in logs
        self.engine.log("⚡ Submit 전용 Auto Clicker 준비 완료 [F8]")

    def setup_ui(self):
        # 1. Header Frame
        header_frame = ctk.CTkFrame(self, fg_color="#0d1424", corner_radius=0, height=56)
        header_frame.pack(fill="x", side="top")
        header_frame.pack_propagate(False)

        header_content = ctk.CTkFrame(header_frame, fg_color="transparent")
        header_content.pack(fill="both", expand=True, padx=16, pady=6)

        # Left title & subtitle
        title_box = ctk.CTkFrame(header_content, fg_color="transparent")
        title_box.pack(side="left", fill="y")

        lbl_app_title = ctk.CTkLabel(
            title_box,
            text="⚡ ANTIGRAVITY AUTO CLICKER",
            font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
            text_color="#f8fafc"
        )
        lbl_app_title.pack(anchor="w")

        lbl_app_sub = ctk.CTkLabel(
            title_box,
            text="Submit 전용 자동 승인",
            font=ctk.CTkFont(family="Segoe UI", size=10),
            text_color="#94a3b8"
        )
        lbl_app_sub.pack(anchor="w")

        # Right: Pin to top switch
        self.var_pin_top = ctk.BooleanVar(value=False)
        self.sw_pin = ctk.CTkSwitch(
            header_content,
            text="📌 항상 위",
            variable=self.var_pin_top,
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            text_color="#cbd5e1",
            progress_color="#6366f1",
            command=self.toggle_pin_top,
            width=36,
            height=18
        )
        self.sw_pin.pack(side="right", padx=4)

        # Main Container
        main_container = ctk.CTkFrame(self, fg_color="transparent", corner_radius=0)
        main_container.pack(fill="both", expand=True, padx=14, pady=8)

        # 2. Hero Status Card
        card_hero = ctk.CTkFrame(main_container, fg_color="#0f172a", border_width=1, border_color="#1e293b", corner_radius=12)
        card_hero.pack(fill="x", pady=(0, 6))

        self.lbl_status = ctk.CTkLabel(
            card_hero,
            text="○ STOPPED - 일시 정지 (대기 중)",
            font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
            text_color="#94a3b8"
        )
        self.lbl_status.pack(pady=(10, 4))

        # Big Action Button (F8)
        self.btn_toggle = ctk.CTkButton(
            card_hero,
            text="▶ Submit 자동 승인 시작 (F8)",
            font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
            fg_color="#f43f5e",
            hover_color="#e11d48",
            corner_radius=10,
            height=40,
            command=self.engine.toggle
        )
        self.btn_toggle.pack(fill="x", padx=16, pady=(0, 8))

        # Stats row
        stats_frame = ctk.CTkFrame(card_hero, fg_color="#080c14", corner_radius=8, height=30)
        stats_frame.pack(fill="x", padx=16, pady=(0, 10))

        self.lbl_stat_count = ctk.CTkLabel(
            stats_frame,
            text="누적 승인: 0회",
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            text_color="#38bdf8"
        )
        self.lbl_stat_count.pack(side="left", padx=12, pady=3)

        self.lbl_stat_last = ctk.CTkLabel(
            stats_frame,
            text="최근 클릭: 없음",
            font=ctk.CTkFont(family="Segoe UI", size=11),
            text_color="#94a3b8"
        )
        self.lbl_stat_last.pack(side="right", padx=12, pady=3)

        # 3. Delay & Mouse Safety Card
        card_safety = ctk.CTkFrame(main_container, fg_color="#0f172a", border_width=1, border_color="#1e293b", corner_radius=12)
        card_safety.pack(fill="x", pady=4)

        slider_row = ctk.CTkFrame(card_safety, fg_color="transparent")
        slider_row.pack(fill="x", padx=14, pady=(8, 2))

        ctk.CTkLabel(
            slider_row,
            text="클릭 전 대기 지연 시간:",
            font=ctk.CTkFont(family="Segoe UI", size=10),
            text_color="#cbd5e1"
        ).pack(side="left")

        self.lbl_delay = ctk.CTkLabel(
            slider_row,
            text="0.05초 (초고속 즉각 승인)",
            font=ctk.CTkFont(family="Segoe UI", size=10, weight="bold"),
            text_color="#38bdf8"
        )
        self.lbl_delay.pack(side="right")

        self.slider_delay = ctk.CTkSlider(
            card_safety,
            from_=0.0,
            to=1.5,
            number_of_steps=30,
            command=self.on_slider_change,
            progress_color="#6366f1",
            button_color="#818cf8"
        )
        self.slider_delay.set(self.engine.delay_sec)
        self.slider_delay.pack(fill="x", padx=14, pady=(2, 6))

        # Restore mouse switch
        self.var_restore = ctk.BooleanVar(value=self.engine.restore_mouse)
        self.sw_restore = ctk.CTkSwitch(
            card_safety,
            text="클릭 직후 원래 마우스 위치로 복귀",
            variable=self.var_restore,
            font=ctk.CTkFont(family="Segoe UI", size=10),
            text_color="#e2e8f0",
            progress_color="#10b981",
            command=self.update_engine_settings
        )
        self.sw_restore.pack(anchor="w", padx=14, pady=(0, 8))

        # 4. Live Activity Log Card
        card_log = ctk.CTkFrame(main_container, fg_color="#0f172a", border_width=1, border_color="#1e293b", corner_radius=12)
        card_log.pack(fill="both", expand=True, pady=4)

        log_header = ctk.CTkFrame(card_log, fg_color="transparent")
        log_header.pack(fill="x", padx=14, pady=(6, 2))

        ctk.CTkLabel(
            log_header,
            text="📋 실시간 로그",
            font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"),
            text_color="#f8fafc"
        ).pack(side="left")

        btn_clear = ctk.CTkButton(
            log_header,
            text="비우기",
            width=50,
            height=20,
            font=ctk.CTkFont(family="Segoe UI", size=9),
            fg_color="#1e293b",
            hover_color="#334155",
            corner_radius=6,
            command=self.clear_logs
        )
        btn_clear.pack(side="right")

        self.txt_log = ctk.CTkTextbox(
            card_log,
            fg_color="#080c14",
            text_color="#e2e8f0",
            font=ctk.CTkFont(family="Consolas", size=10),
            corner_radius=8,
            border_width=1,
            border_color="#1e293b"
        )
        self.txt_log.pack(fill="both", expand=True, padx=14, pady=(2, 8))

        # 5. Bottom Status Bar
        statusbar = ctk.CTkFrame(self, fg_color="#0d1424", height=26, corner_radius=0)
        statusbar.pack(fill="x", side="bottom")
        statusbar.pack_propagate(False)

        self.lbl_statusbar = ctk.CTkLabel(
            statusbar,
            text="단축키: [F8] 시작/일시정지 토글  |  [F9] 비상 정지",
            font=ctk.CTkFont(family="Segoe UI", size=10),
            text_color="#94a3b8"
        )
        self.lbl_statusbar.pack(side="left", padx=14, pady=1)

    def toggle_pin_top(self):
        self.attributes("-topmost", self.var_pin_top.get())

    def on_slider_change(self, val):
        v = round(float(val), 2)
        if v <= 0.05:
            self.lbl_delay.configure(text=f"{v:.2f}초 (초고속 즉각 승인)", text_color="#38bdf8")
        elif v <= 0.3:
            self.lbl_delay.configure(text=f"{v:.2f}초 (빠름)", text_color="#10b981")
        else:
            self.lbl_delay.configure(text=f"{v:.2f}초 (안전 지연)", text_color="#fb7185")
        self.engine.delay_sec = v

    def update_engine_settings(self):
        self.engine.restore_mouse = self.var_restore.get()

    def on_status_change(self, is_running):
        def _update():
            if is_running:
                self.lbl_status.configure(text="● RUNNING - Submit 감시 중", text_color="#10b981")
                self.btn_toggle.configure(text="⏸ 일시 정지 (F8)", fg_color="#334155", hover_color="#475569")
            else:
                self.lbl_status.configure(text="○ STOPPED - 일시 정지 (대기 중)", text_color="#94a3b8")
                self.btn_toggle.configure(text="▶ Submit 자동 승인 시작 (F8)", fg_color="#f43f5e", hover_color="#e11d48")
        self.after(0, _update)

    def on_log(self, text):
        def _append():
            if "승인 완료" in text:
                self.click_count += 1
                self.lbl_stat_count.configure(text=f"누적 승인: {self.click_count}회")
                now_str = time.strftime("%H:%M:%S")
                self.lbl_stat_last.configure(text=f"최근 클릭: {now_str}")

            self.txt_log.insert("end", text + "\n")
            self.txt_log.see("end")
        self.after(0, _append)

    def clear_logs(self):
        self.txt_log.delete("1.0", "end")

    def on_close(self):
        self.engine.stop()
        self.engine._hotkey_running = False
        self.destroy()
        sys.exit(0)

if __name__ == "__main__":
    import traceback
    try:
        app = ModernAutoClickerApp()
        app.mainloop()
    except Exception as e:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "crash.log"), "w", encoding="utf-8") as f:
            f.write(traceback.format_exc())
        raise
